import React from 'react'

const Print = () => {
  return (
    <div>Print</div>
  )
}

export default Print