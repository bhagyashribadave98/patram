import React from 'react';  
  
export const Profile = () => {
    return(
        <div>
            <h1>Hello</h1>
        </div>    
    )
}
//export default Profile;